<template>
  <div id="app">
    <!-- router-view sẽ tự động hiển thị component theo route -->
    <router-view />
  </div>
</template>

<script setup>
// Không cần code JS ở đây nếu bạn chỉ hiển thị router-view
</script>

<style>
body {
  margin: 0;
  font-family: "Segoe UI", Roboto, sans-serif;
  background-color: #f9f9f9;
}
</style>
