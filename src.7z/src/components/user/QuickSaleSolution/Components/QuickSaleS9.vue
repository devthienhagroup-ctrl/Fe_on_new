<template>
  <div class="section section9" :id="sectionData.id">
    <div class="st-title">
      <TitleComponent
          :circle-size="sectionData.circleSize"
          :icon-height="sectionData.icon.height"
          :icon-width="sectionData.icon.width"
          :order-number="sectionData.orderNumber"
          component-height="100px"
          component-width="100%"
          :icon-url="baseImgaeUrl+sectionData.icon.url"
          :title="sectionData.title"
      />
    </div>

    <div class="main-content-wrapper">
      <div class="left-content-section">
        <div v-for="img in sectionData.images.filter(img => img.class.includes('fade-left'))"
             :key="img.id"
             :class="img.class.split(' ')[0]"
             :style="{ transform: img.transform }">
          <img :class="img.class.split(' ')[1]" :src="baseImgaeUrl+img.src" :alt="img.alt">
        </div>
        <img :src="baseImgaeUrl+sectionData.backgroundImages.left" alt="" class="bottom-left-img">
      </div>

      <div class="right-content-section">
        <div class="right-img fade-up">
          <img :src="baseImgaeUrl+sectionData.images.find(img => img.id === 'image4').src"
               :alt="sectionData.images.find(img => img.id === 'image4').alt">
        </div>
        <div class="text-content-wrapper">
          <div class="text-content fade-right">
            <p :style="{
              marginBottom: '20px',
              lineHeight: sectionData.content.styles.lineHeight,
              fontSize: sectionData.content.styles.fontSize,
              color: sectionData.content.styles.color,
              textAlign: 'justify'
            }">
              {{ sectionData.content.text }}
            </p>
          </div>
        </div>
        <img class="bottom-right-img" :src="baseImgaeUrl+sectionData.backgroundImages.right" alt="">
      </div>
    </div>
  </div>
</template>

<script setup>
import TitleComponent from "./TitleQickSale.vue";
import { ref, onMounted } from 'vue';
import {baseImgaeUrl} from "../../../../assets/js/global.js";

// Dữ liệu mặc định
let defaultData = {
  id: "section9",
  orderNumber: 9,
  title: "Hỗ trợ đàm phán để bán được giá cao nhất",
  icon: {
    url: "/imgs/icon-ho-tro.png",
    width: 109,
    height: 109
  },
  circleSize: 100,
  backgroundImages: {
    left: "/imgs/bg-s4.png",
    right: "/imgs/bg-s3.png"
  },
  images: [
    {
      id: "image1",
      src: "/imgs/anh-ho-tro-1.png",
      alt: "Hỗ trợ đàm phán 1",
      class: "top-img fade-left"
    },
    {
      id: "image2",
      src: "/imgs/anh-ho-tro-2.png",
      alt: "Hỗ trợ đàm phán 2",
      class: "mid-img fade-left",
      transform: "translate(100px, -100px)"
    },
    {
      id: "image3",
      src: "/imgs/anh-ho-tro-3.png",
      alt: "Hỗ trợ đàm phán 3",
      class: "bot-img fade-left",
      transform: "translate(200px, -200px)"
    },
    {
      id: "image4",
      src: "/imgs/anh-ho-tro-4.png",
      alt: "Hỗ trợ đàm phán 4",
      class: "right-img fade-up"
    }
  ],
  content: {
    text: "Các chuyên viên giàu kinh nghiệm đại diện chủ nhà tham gia đàm phán, giúp thương lượng giá tối ưu nhất dựa trên dữ liệu thị trường, đảm bảo giao dịch nhanh mà vẫn có lợi nhất cho khách hàng.",
    styles: {
      backgroundColor: "white",
      maxWidth: "500px",
      fontSize: "17px",
      lineHeight: "1.6",
      color: "#333"
    }
  }
};

// Props để nhận dữ liệu từ CMS
const props = defineProps({
  sectionData: {
    type: Object,
  }
});

// Dữ liệu section - ưu tiên dữ liệu từ CMS
const sectionData = ref({defaultData});
if(props.sectionData) {
  sectionData.value = props.sectionData.section9;
}

</script>

<style scoped>
.section {
  padding: v-bind('sectionData.styles?.sectionPadding || "50px 50px 0"');
  margin-top: v-bind('sectionData.styles?.sectionMarginTop || "250px"');
  position: relative;
  overflow: visible;
}

.title-component { z-index: 1; }

.st-title {
  position: relative;
  width: 40%;
}
.st-title::before {
  content: "";
  position: absolute;
  border-left: v-bind('sectionData.styles?.borderWidth || "5px"')
  v-bind('sectionData.styles?.borderStyle || "dashed"')
  v-bind('sectionData.styles?.borderColor || "#C2CBF0"');
  width: 100%;
  height: 243%;
  bottom: 070px;
  left: 45px;
}
.st-title::after {
  content: "";
  position: absolute;
  border-right: v-bind('sectionData.styles?.borderWidth || "5px"')
  v-bind('sectionData.styles?.borderStyle || "dashed"')
  v-bind('sectionData.styles?.borderColor || "#C2CBF0"');
  width: 100%;
  height: 175%;
  top: -30px;
  left: 0;
}

.bottom-right-img {
  position: absolute;
  width: 70%;
  right: 0;
}

.bottom-left-img {
  position: absolute;
  bottom: -0px;
  left: 0px;
  width: 100%;
  border-radius: 10px;
  z-index: -1;
}

.top-img::before,
.mid-img::before,
.bot-img::before {
  content: "";
  position: absolute;
  border-top: v-bind('sectionData.styles?.borderWidth || "5px"')
  v-bind('sectionData.styles?.borderStyle || "dashed"')
  v-bind('sectionData.styles?.borderColor || "#C2CBF0"');
  border-right: v-bind('sectionData.styles?.borderWidth || "5px"')
  v-bind('sectionData.styles?.borderStyle || "dashed"')
  v-bind('sectionData.styles?.borderColor || "#C2CBF0"');
}
.top-img::before { width: 21%; height: 34%; top: 50px; right: 0; }
.mid-img::before { width: 18%; height: 62.7%; top: -20px; right: -20px; }
.bot-img::before { width: 15%; height: 177%; top: -20px; right: -20px; }

.top-img img,
.mid-img img,
.bot-img img {
  display: block;
  margin-left: auto;
}

.right-img img {
  display: block;
  margin: 0 auto;
}
.right-img { position: relative; }

.text-content-wrapper {
  position: relative;
  border-left: 0;
  border-top-right-radius: 50px;
  display: block;
  margin: 5px auto;
  max-width: v-bind('sectionData.content.styles.maxWidth || "500px"');
  background-color: v-bind('sectionData.content.styles.backgroundColor || "white"');
}

.section9 .title-component { transform: translateY(-70px); }

.main-content-wrapper {
  display: flex;
}
.left-content-section,
.right-content-section {
  flex: 1;
  min-width: 0;
  position: relative;
}
.left-content-section {
  z-index: 3;
  padding-top: 50px;
}
.right-content-section {
  z-index: 2;
  transform: translateY(-50px);
}

/* Responsive - giữ nguyên CSS gốc */
@media (max-width: 1400px) {
  .section9::before {
    content: "";
    position: absolute;
    height: 105%;
    width: 2px;
    border-left: v-bind('sectionData.styles?.borderWidth || "5px"')
    v-bind('sectionData.styles?.borderStyle || "dashed"')
    v-bind('sectionData.styles?.borderColor || "#C2CBF0"');
    top: 0;
    left: 100px;
  }

  .st-title {
    width: 100%;
  }
  .st-title::before, .st-title::after {
    display: none !important;
  }

  .st-title::before,
  .st-title::after,
  .top-img::before,
  .mid-img::before,
  .bot-img::before {
    display: none;
  }

  .st-title {
    position: relative;
  }
  .st-title::after {
    display: block;
    content: "";
    position: absolute;
    border-left: 2px dashed v-bind('sectionData.styles?.borderColor || "#C2CBF0"');
    width: 2px;
    height: 100%;
    left: 0;
    top: 0;
    bottom: 0;
  }

  .top-img img,
  .mid-img img,
  .bot-img img {
    max-width: 80%;
    height: auto;
  }
}

@media (max-width: 1308px) {
  .img-right::before,
  .text-content-wrapper::before { display: none }
  .text-content-wrapper::before { height: 300%; }
  .right-imgimg { transform: translate(0, 0); height: 100%; }
  .right-img { height: 145px; }
}

@media (max-width: 992px) {
  .main-content-wrapper {
    flex-direction: column;
    gap: 20px;
  }
  .left-content-section,
  .right-content-section {
    flex: none;
    width: 100%;
  }

  .right-content-section::before,
  .text-content-wrapper::before { display: none }

  .section9 {
    position: relative;
  }
  .bottom-right-img {
    display: none;
  }
  .text-content-wrapper {
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    border-radius: 20px;
    padding: 20px;
  }
  .right-imgimg {
    border-radius: 50px;
    height: 100%;
  }
  .right-img { height: 100%; }
}

@media (max-width: 768px) {
  .section {
    padding: 20px;
    margin-bottom: 30px;
    margin-top: 150px;
  }

  .top-img,
  .mid-img,
  .bot-img {
    text-align: center;
  }

  .top-img img,
  .mid-img img,
  .bot-img img {
    margin: 0 auto;
    max-width: 100%;
    transform: none !important;
  }

  .mid-img,
  .bot-img {
    transform: none !important;
    margin-top: 20px;
  }

  .right-content-section {
    transform: none;
  }

  .text-content-wrapper {
    margin-top: 20px;
  }
}

@media (max-width: 576px) {
  .section {
    padding: 15px;
    margin-top: 100px;
  }

  .section9 .title-component {
    transform: translateY(-30px);
  }

  .left-content-section {
    padding-top: 20px;
  }

  .section9::before {
    left: 63px;
    top: 0;
  }
}
</style>